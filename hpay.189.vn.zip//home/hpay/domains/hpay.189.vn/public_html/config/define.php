<?php
    define('SITEOFF','yes1');
    define('TPL','/theme');
    define('TPL_LINK',WEB_DOMAIN.TPL);
    //define('WEB_NAME','Hoang Gia INC');
    
    

?>