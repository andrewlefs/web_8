<footer>
		<div class="float-left">
			<span class="button">2011 Hoanggia.net</span>
		</div>
		<div class="float-right">
			<a href="#top" class="button"><img src="css/images/icons/fugue/navigation-090.png" width="16" height="16">Lên đầu trang</a>
		</div>
	</footer>
<!--[if lt IE 8]></div><![endif]-->
<!--[if lt IE 9]></div><![endif]-->
<script type="text/javascript" src="js/admin.js"></script>
</body>
</html>