<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");
	}
?>
<html>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<LINK href="mstyle.css" rel=stylesheet type=text/css>
<title>Hshop >> Ho thong quan tri website >> Hoanggia.net</title>
</head>
<body><div align="center">
	<table width="900" border="0" align="center" cellpadding="2" cellspacing="0">
	<tbody>
	  <tr bgcolor="whitesmoke">
	    <td width="143" align="center" class="logout">[ <a href="index.php?pages=logout">Logout</a> ]</td>
	    <td align="center" class="manager_link">Cấu hình cho website</td>
      </tr>
	  </tbody>
</table> 
	
	
      <table width="900" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td bgcolor='whitesmoke' width="147" height="100%" valign="top"><?php include("menu.php")?></td>
     <td width="100%" valign="top" class="alert">
	<div align="center">
      <br />
      <strong>Cập nhật thành công</strong></div></td>
        </tr>
</table> <br>
</div></body>
</html>